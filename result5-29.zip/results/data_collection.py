import os
import pandas as pd
import argparse

def collect_results_by_pre_l(results_dir=".", pre_l=1, output_file=None, dataset=None):
    if output_file is None:
        output_file = f"all_results_pre{pre_l}.csv" if not dataset else f"all_results_{dataset}_pre{pre_l}.csv"
    pattern = f"_{pre_l}bs"
    files = [f for f in os.listdir(results_dir) if f.endswith(".csv") and pattern in f]
    if dataset:
        files = [f for f in files if dataset in f]
    all_results = []
    for f in files:
        model_name = f.split("_")[0]
        df = pd.read_csv(os.path.join(results_dir, f))
        df.insert(0, "model", model_name)
        all_results.append(df)
    if all_results:
        merged = pd.concat(all_results, ignore_index=True)
        merged.to_csv(os.path.join(results_dir, output_file), index=False)
        print(f"Saved merged results to {output_file}")
    else:
        print(f"No pre_l={pre_l} result files found for dataset={dataset}.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Collect results by pre_l value.")
    parser.add_argument('--results_dir', type=str, default=".", help='Results directory')
    parser.add_argument('--pre_l', type=int, default=1, help='pre_l value to filter')
    parser.add_argument('--output_file', type=str, default=None, help='Output csv file name')
    parser.add_argument('--dataset', type=str, default=None, help='Dataset name prefix to filter (e.g. PEMS-BAY or ST-EVCDP)')
    args = parser.parse_args()
    collect_results_by_pre_l(results_dir=args.results_dir, pre_l=args.pre_l, output_file=args.output_file, dataset=args.dataset)
